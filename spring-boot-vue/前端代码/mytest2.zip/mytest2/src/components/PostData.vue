<template>
    <div>
        <button type="button" @click="postData()">postData</button><br/>
    </div>
</template>

<!--
PSOT 请求 + 普遍变量传参
axios 异步 POST 请求的方法为 axios.post(url,params).then()
url：请求的 URL
params：参数，POST 请求中，参数格式不再是  {params:{name:value,name:value}} ，而需要将参数封装到 URLSearchParams 对象中。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "PostData",
        methods: {
            postData(){
                const _this = this
                var params = new URLSearchParams();
                params.append("id", '1');
                params.append('name', '梦梦');
                axios.post('http://localhost:8181/data/postData', params).then(function (resp) {
                    console.log(resp.data)
                })
            }
        }
    }
</script>

<style scoped>

</style>
