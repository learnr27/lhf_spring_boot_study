<template>
    <div>
        <button type="button" @click="restfulPutData()">restfulPutData</button>
    </div>
</template>

<!--
基于 RESTful PUT 请求 + 普通变量传参
基于 RESTful 的 axios 异步 POST 请求的方法为 axios.put(url).then()
url：请求的 URL，直接追加参数。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "RestfulPutData",
        methods:{
            restfulPutData(){
                const _this = this;
                axios.put("http://localhost:8181/data/restfulPutData/1").then(function (resp) {
                    console.log(resp.data)
                })

            }
        }
    }
</script>

<style scoped>

</style>
