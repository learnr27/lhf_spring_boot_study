<template>
    <div>
        <button type="button" @click="getJson()">getJson</button><br/>
    </div>
</template>

<!--
GET请求 + JSON传参
axios异步GET请求的方法为：axios.get(url, params).then()
url: 请求的URL
params：参数，格式为：{params: json}
then(): 请求成功的回调函数
-->
<script>
    export default {
        name: "GetJson",
        methods: {
            getJson(){
                const _this = this
                var girl = {
                    id: 1,
                    name: '梦梦'
                }
                axios.get('http://localhost:8181/data/getJson', {params: girl}).then(function (resp) {
                    console.log(resp.data)
                })
            }
        }
    }
</script>

<style scoped>

</style>
