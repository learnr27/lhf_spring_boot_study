<template>
    <div>
        <button type="button" @click="getData()">getData</button><br/>
    </div>
</template>

<!--
GET请求 + 普通变量传参
axios异步GET请求的方法为：axios.get(url, params).then()
url: 请求的URL
params：参数，格式为：{params: {name: value, name:value}}
then(): 请求成功的回调函数
-->
<script>
    export default {
        name: "GetData",
        methods: {
            getData(){
                const _this = this
                axios.get('http://localhost:8181/data/getData',{params: {id:1,name:'梦梦'}}).then(function (resp) {
                    console.log(resp.data)
                })
            }
        }
    }
</script>

<style scoped>

</style>
