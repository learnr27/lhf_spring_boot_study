<template>
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="form-container">
        <el-form-item label="女孩编号" prop="id">
            <el-input v-model="ruleForm.id" readonly=""></el-input>
        </el-form-item>
        <el-form-item label="女孩芳名" prop="name">
            <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <el-form-item label="年龄" prop="age">
            <el-input v-model="ruleForm.age"></el-input>
        </el-form-item>
        <el-form-item label="身高" prop="height">
            <el-input v-model="ruleForm.height"></el-input>
        </el-form-item>
        <el-form-item label="体重" prop="weight">
            <el-input v-model="ruleForm.weight"></el-input>
        </el-form-item>
        <el-form-item label="罩杯尺码" prop="cupSize">
            <el-select style="margin-left: -280px;" v-model="ruleForm.cupSize" placeholder="请选择罩杯尺码">
                <el-option v-for="(item,index) in cupSizeData" :label="item.value" :value="item.value"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">修改</el-button>
        </el-form-item>
    </el-form>

</template>

<script>
    export default {
        data() {
            return {
                cupSizeData:[
                    {
                        id: 1,
                        value:'A罩杯'
                    },
                    {
                        id: 2,
                        value:'B罩杯'
                    },
                    {
                        id: 3,
                        value:'C罩杯'
                    },
                    {
                        id: 4,
                        value:'D罩杯'
                    },
                    {
                        id: 5,
                        value:'E罩杯'
                    },
                    {
                        id: 6,
                        value:'F罩杯'
                    },
                    {
                        id: 7,
                        value:'G罩杯'
                    }
                ],
                ruleForm: {
                    id: '',
                    name: '',
                    age: '',
                    height:'',
                    weight: '',
                    cupSize: ''
                },
                rules: {
                    id: [
                        { required: true, message: '请输入女孩编号', trigger: 'blur' }
                    ],
                    name: [
                        { required: true, message: '请输入女孩芳名', trigger: 'blur' }
                    ],
                    age: [
                        { required: true, message: '请输入女孩年龄', trigger: 'blur' }
                    ],
                    height: [
                        { required: true, message: '请选择女孩身高', trigger: 'change' }
                    ],
                    weight: [
                        { required: true, message: '请输入女孩体重', trigger: 'blur' }
                    ],
                    cupSize: [
                        { required: true, message: '请输入女孩罩杯尺码', trigger: 'blur' }
                    ]
                }
            };
        },
        methods: {
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        console.log(this.ruleForm);
                        //this.ruleForm.bookCase = {id:this.ruleForm.bookCaseId}
                        const _this = this
                        axios.put('http://localhost:8181/girl/updateGirl',this.ruleForm).then(function (resp) {
                            console.log(resp.data);
                            if(resp.data == 1){
                                _this.$alert('修改成功！', '', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        _this.$router.push("/girl")
                                    }
                                });
                            }
                        })
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            }
        },
        created() {
            const _this = this
            axios.get('http://localhost:8181/girl/findById/'+this.$route.query.id).then(function (resp) {
                console.log("findById:" + resp.data);
                _this.ruleForm.id = resp.data.id;
                _this.ruleForm.name = resp.data.name;
                _this.ruleForm.age = resp.data.age;
                _this.ruleForm.height = resp.data.height;
                _this.ruleForm.weight = resp.data.weight;
                _this.ruleForm.cupSize = resp.data.cupSize;
            })
        }
    }
</script>

<style>
    .form-container {
        border-radius: 15px;
        background-clip: padding-box;
        margin: 0px auto;
        width: 600px;
        padding: 35px 35px 15px 35px;
        background: #fff;
        border: 1px solid #eaeaea;
        box-shadow: 0 0 25px #cac6c6;
    }

    .login_title {
        margin: 0px auto 40px auto;
        text-align: center;
        color: #505458;
    }

    .login_remember {
        margin: 0px 0px 35px 0px;
        text-align: left;
    }
</style>
