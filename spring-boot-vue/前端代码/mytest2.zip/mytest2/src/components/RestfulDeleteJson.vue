<template>
    <div>
        <button type="button" @click="restfulDeleteJson()">restfulDeleteJson</button>
    </div>
</template>

<!--
基于 RESTful DELETE 请求 + JSON 传参
基于 RESTful 的 axios 异步 POST 请求的方法为 axios.delete(url,params).then()
url：请求的 URL。
params：参数，格式为  {params:{name:value,name:value}} 。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "RestfulDeleteJson",
        methods:{
            restfulDeleteJson(){
                const _this = this;
                var book = {
                    id: 10,
                    name: '活着'
                };
                axios.delete('http://localhost:8181/data/restfulDeleteJson', {params: book}).then(function (resp) {
                    console.log(resp.data)
                })
            }
        }
    }
</script>

<style scoped>

</style>
