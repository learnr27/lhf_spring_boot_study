<template>
    <div>
        <button type="button" @click="restfulPostData()">restfulPostData</button>
    </div>
</template>

<!--
基于 RESTful POST 请求 + 普通变量传参
基于 RESTful 的 axios 异步 POST 请求的方法为 axios.post(url).then()
url：请求的 URL，直接追加参数。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "RestfulPostData",
        methods:{
            restfulPostData(){
                const _this = this
                axios.post('http://localhost:8181/data/restfulPostData/1').then(function (resp) {
                    console.log(resp.data)
                })
            }
        }
    }
</script>

<style scoped>

</style>
