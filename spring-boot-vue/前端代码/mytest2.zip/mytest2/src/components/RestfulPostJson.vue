<template>
    <div>
        <button type="button" @click="restfulPostJson()">restfulPostJson</button>
    </div>
</template>

<!--
基于 RESTful POST 请求 + JSON 传参
基于 RESTful 的 axios 异步 POST 请求的方法为 axios.post(url,params).then()
url：请求的 URL。
params：参数，需要将参数封装到 URLSearchParams 对象中。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "RestfulPostJson",
        methods:{
            restfulPostJson(){
                const _this = this
                var params = new URLSearchParams();
                params.append("id", "1");
                params.append("name", "梦梦");
                axios.post("http://localhost:8181/data/restfulPostJson", params).then(function (resp) {
                    console.log(resp.data);
                })
            }
        }
    }
</script>

<style scoped>

</style>
