<template>
    <div>
        <div>
            <el-table
                :data="girlData"
                border
                style="width:80%; margin-left: 100px; margin-top: 30px;">
                <el-table-column
                        fixed
                        prop="id"
                        label="编号"
                        width="100">
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="芳名"
                    width="150">
                </el-table-column>
                <el-table-column
                    prop="age"
                    label="芳龄"
                    width="150">
                </el-table-column>
                <el-table-column
                    prop="height"
                    label="身高(cm)"
                    width="150">
                </el-table-column>
                <el-table-column
                    prop="weight"
                    label="体重(kg)"
                    width="150">
                </el-table-column>
                <el-table-column
                    prop="cupSize"
                    label="罩杯"
                    width="150">
                </el-table-column>
                <el-table-column
                    fixed="right"
                    label="操作"
                    width="100">
                    <template slot-scope="scope">
                        <el-button @click="findById(scope.row.id)" type="text" size="small">修改</el-button>
                        <el-button @click="deleteById(scope.row)" type="text" size="small">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                background
                layout="prev, pager, next"
                :total="total"
                :page-size="pageSize"
                @current-change="change">
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        //name: "GirlList",
        methods : {
            findById(id){
                this.$router.push({path:'/updateGirl', query: {id:id}})
            },
            change(currentPage){
                this.currentPage = currentPage
                const _this = this
                axios.get('http://localhost:8181/girl/findByPage/' + currentPage).then(function (resp) {
                    _this.girlData = resp.data.data
                })
            },
            deleteById(row) {
                this.$confirm('确定删除《'+row.name+'》?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    const _this = this
                    axios.delete('http://localhost:8181/girl/deleteById/'+row.id).then(function (resp) {
                        if(resp.data == 1){
                            axios.get('http://localhost:8181/girl/findByPage/'+_this.currentPage).then(function (resp) {
                                // _this.$message({
                                //     type: 'success',
                                //     message: '删除成功!'
                                // });
                                //_this.tableData = resp.data.data

                                _this.$alert('删除成功！', '', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        _this.girlData = resp.data.data
                                    }
                                });

                            })
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            }
        },
        data(){
            return{
                total: 0,
                pageSIze: 5,
                girlData: [],
                currentPage: 0
            }
        },

        created() {
            const _this = this
            axios.get('http://localhost:8181/girl/findByPage/1').then(function (resp) {
                console.log(resp.data);
                _this.pageSize = resp.data.pageSize;
                _this.total = resp.data.total;
                _this.girlData = resp.data.data;
            })
        }
    }
</script>

<style scoped>

</style>
