<template>
    <div>
        <button type="button" @click="postJson()">postJson</button>
    </div>
</template>

<!--
PSOT 请求 + JSON传参
axios 异步 POST 请求的方法为 axios.post(url,params).then()
url：请求的 URL
params：参数，POST 请求中，参数格式不再是  {params:{name:value,name:value}} ，而需要将参数封装到 URLSearchParams 对象中。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "PostJson",
        methods:{
            postJson(){
                const _this = this;
                var params = new URLSearchParams();
                params.append('id', '15');
                params.append('name', '鱼菲儿');
                params.append('age', '24');
                params.append('height', '170');
                params.append('weight', '55');
                params.append('cupSize', 'D罩杯');
                axios.post('http://localhost:8181/data/postJson', params).then(function (resp) {
                    console.log(resp.data)
                    if(resp.data == 1){
                        _this.$alert('添加成功！', '', {
                            confirmButtonText: '确定',
                            callback: action => {
                                _this.$router.push("/girl")
                            }
                        });
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>
