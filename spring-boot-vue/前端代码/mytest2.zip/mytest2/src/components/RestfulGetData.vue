<template>
    <div>
        <button type="button" @click="restfulGetData()">restfulGetData</button>
    </div>
</template>

<!--
基于 RESTful GET 请求 + 普遍变量传参
基于 RESTful 的 axios 异步 GET 请求的方法为 axios.gett(url).then()
url：请求的 URL，直接追加参数。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "RestfulGetData",
        methods: {
            restfulGetData(){
                const _this = this
                axios.get('http://localhost:8181/data/restfulGetData/1').then(function (resp) {
                    console.log(resp.data)
                })
            }
        }
    }
</script>

<style scoped>

</style>
