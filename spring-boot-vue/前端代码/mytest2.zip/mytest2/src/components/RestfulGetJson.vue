<template>
    <div>
        <button type="button" @click="restfulGetJson()">restfulGetJson</button>
    </div>
</template>

<!--
基于 RESTful GET 请求 + JSON 传参
基于 RESTful 的 axios 异步 GET 请求的方法为 axios.get(url,params).then()
url：请求的 URL。
params：参数，格式为  {params:{name:value,name:value}} 。
then()：请求成功的回调函数。
-->
<script>
    export default {
        name: "RestfulGetJson",
        methods: {
            restfulGetJson(){
                const _this = this
                axios.get('http://localhost:8181/data/restfulGetJson',
                    {params: {id:16, name: '追风筝的人', author: '卡勒德·胡赛尼', publish: '上海人民出版社', pages: '362', price: '88'}}).then(function (resp) {
                    console.log(resp.data)
                    if(resp.data == 1){
                        _this.$alert('添加成功！', '', {
                            confirmButtonText: '确定',
                            callback: action => {
                                _this.$router.push("/")
                            }
                        });
                    }
                })

            }
        }
    }
</script>

<style scoped>

</style>
