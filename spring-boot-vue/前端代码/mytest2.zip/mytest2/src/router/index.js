import Vue from 'vue'
import Router from 'vue-router'
import Home from '../components/Home'
import Table from '../components/Table'
import Form from '../components/Form'
import Login from '../components/Login'

import BarCharts from '../components/BarCharts'
import PieCharts from '../components/PieCharts'
import ScatterCharts from '../components/ScatterCharts'

import Update from '../components/Update'
import GirlList from '../components/GirlList'
import AddGirl from '../components/AddGirl'
import UpdateGirl from '../components/UpdateGirl'
import Test from '@/components/Test'

import GetData from '../components/GetData'
import GetJson from '../components/GetJson'
import PostData from '../components/PostData'
import PostJson from '../components/PostJson'
import RestfulGetData from '../components/RestfulGetData'
import RestfulGetJson from '../components/RestfulGetJson'
import RestfulPostData from '../components/RestfulPostData'
import RestfulPostJson from '../components/RestfulPostJson'
import RestfulPutData from '../components/RestfulPutData'
import RestfulPutJson from  '../components/RestfulPutJson'
import RestfulDeleteData from '../components/RestfulDeleteData'
import RestfulDeleteJson from '../components/RestfulDeleteJson'

Vue.use(Router)

const router = new Router({

    mode: 'history',
    // routes:[
    //     {path: '/login', component: Login, name: '登录'},
    //     {
    //         path: '/',
    //         name: '图书管理',
    //         component: Test,
    //         iconCls: 'el-icon-message',
    //         redirect: '/table',
    //         menuShow: true,
    //         children: [
    //             {path: '/table', component: Table, name: '查询图书',menuShow: true},
    //             {path: '/form', component: Form, name: '添加图书',menuShow: true}
    //         ]
    //     },
    //     {
    //         path: '/charts',
    //         name: '数据统计',
    //         component: Test,
    //         iconCls: 'el-icon-setting',
    //         menuShow: true,
    //         children: [
    //             {path: '/piecharts', component: PieCharts, name: '饼图',menuShow: true},
    //             {path: '/barcharts', component: BarCharts, name: '柱状图',menuShow: true}
    //         ]
    //     },
    //     {
    //         path: '/update',
    //         name: '修改图书',
    //         component: Test,
    //         redirect: '/edit',
    //         children: [
    //             {path: '/edit', component: Update, name: '修改图书'}
    //         ]
    //     }
    // ]


    routes:[
        {
            path: '/',
            name: '图书管理',
            component: Home,
            // leaf: true, // 只有一个节点
            menuShow: true,
            redirect: '/table',
            iconCls: 'iconfont icon-home', // 图标样式class
            children: [
                {path: '/table', component: Table, name: '查询图书', menuShow: true},
                {path: '/form', component: Form, name: '添加图书', menuShow: true}
            ]
        },
       {
            path: '/girl',
            name: '女孩管理',
            component: Home,
            // leaf: true, // 只有一个节点
            menuShow: true,
            redirect: '/girlList',
            iconCls: 'iconfont icon-home', // 图标样式class
            children: [
                {path: '/girlList', component: GirlList, name: '女孩列表', menuShow: true},
                {path: '/addGirl', component: AddGirl, name: '添加女孩', menuShow: true}
            ]
        },
        {
            path: '/data',
            name: '数据管理',
            component: Home,
            menuShow: true,
            redirect: '/getData',
            iconCls: 'iconfont icon-home',
            children: [
                {path: '/getData', component: GetData, name: 'GET 请求 + 普遍变量传参', menuShow: true},
                {path: '/getJson', component: GetJson, name: 'GET 请求 + JSON数据传参', menuShow: true},
                {path: '/postData', component: PostData, name: 'POST 请求 + 普遍变量传参', menuShow: true},
                {path: '/postJson', component: PostJson, name: 'POST 请求 + JSON数据传参', menuShow: true},
                {path: '/restfulGetData', component: RestfulGetData, name: '基于 RESTful GET 请求 + 普遍变量传参', menuShow: true},
                {path: '/restfulGetJson', component: RestfulGetJson, name: '基于 RESTful GET 请求 + JSON数据传参', menuShow: true},
                {path: '/restfulPostData', component: RestfulPostData, name: '基于 RESTful POST 请求 + 普通变量传参', menuShow: true},
                {path: '/restfulPostJson', component: RestfulPostJson, name: '基于 RESTful POST 请求 + JSON 传参', menuShow: true},
                {path: '/restfulPutData', component: RestfulPutData, name: '基于 RESTful PUT 请求 + 普通变量传参', menuShow: true},
                {path: '/restfulPutJson', component: RestfulPutJson, name: '基于 RESTful PUT 请求 + JSON 传参', menuShow: true },
                {path: '/restfulDeleteData', component: RestfulDeleteData, name: '基于 RESTful DELETE 请求 + 普通变量传参', menuShow: true},
                {path: '/restfulDeleteJson', component: RestfulDeleteJson, name: '基于 RESTful DELETE 请求 + JSON 传参', menuShow: true}
            ]
        },
        {
            path: '/charts',
            name: '数据统计',
            component: Home,
            menuShow: true,
            redirect: '/barcharts',
            iconCls: 'iconfont icon-setting1',
            children: [
                {path: '/barcharts', component: BarCharts, name: '柱状图', menuShow: true},
                {path: '/piecharts', component: PieCharts, name: '饼图', menuShow: true},
                {path: '/scattercharts', component: ScatterCharts, name: '散点图', menuShow: true}
            ]
        },
        {
            path: '/login',
            name: '登录',
            component: Login
        },
        {
            path: '/test',
            name: '登录',
            component: () => import(/* webpackChunkName: "about" */ '../components/Test.vue')
        },
        {
            path: '/update',
            name: '修改图书',
            component: Home,
            redirect: '/edit',
            iconCls: 'iconfont icon-home', // 图标样式class
            children: [
                {path: '/edit', component: Update, name: '修改图书'}
            ]
        },
        {
            path: '/updateGirl',
            name: '修改女孩信息',
            component: Home,
            redirect: '/updateGirl',
            iconCls: 'iconfont icon-home', // 图标样式class
            children: [
                {path: '/updateGirl', component: UpdateGirl, name: '修改女孩信息'}
            ]
        }
        ]
})

router.beforeEach((to, from, next) => {
    // console.log('to:' + to.path)
    if (to.path.startsWith('/login')) {
    window.localStorage.removeItem('access-user')
    next()
} else {
    let user = JSON.parse(window.localStorage.getItem('access-user'))
    if (!user) {
        next({path: '/login'})
    } else {
        next()
    }
}
})

export default router
